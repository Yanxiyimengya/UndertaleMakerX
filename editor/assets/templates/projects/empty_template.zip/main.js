import { UTMX } from "UTMX";
export default class Main
{
	constructor() {
	}
	
	onGameStart()
	{
	}
	
	onGameEnd()
	{
	}
}
